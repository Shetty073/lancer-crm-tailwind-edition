@extends('base')
@section('title', 'Reports')

@section('main-content')

<main class="px-1 lg:px-4 py-2 mx-2 ls:mx-10 my-5 h-screen">
    <p>Reports</p>
</main>

@endsection
